package Pregunta4;
import java.util.ArrayList;

public class Inventario {
	 private ArrayList<Producto> productos;

	    public Inventario() {
	        productos = new ArrayList<>();
	    }

	    
	    public void agregarProducto(String nombre) {
	        productos.add(new Producto(nombre));
	    }

	    
	    public void agregarProducto(String nombre, double precio) {
	        productos.add(new Producto(nombre, precio));
	    }

	    
	    public void agregarProducto(String nombre, double precio, int cantidad) {
	        productos.add(new Producto(nombre, precio, cantidad));
	    }

	    public void mostrarProductos() {
	        if (productos.isEmpty()) {
	            System.out.println("No hay productos en el inventario.");
	        } else {
	            System.out.println("=== Inventario ===");
	            for (Producto p : productos) {
	                System.out.println(p);
	            }
	        }
	    }
}

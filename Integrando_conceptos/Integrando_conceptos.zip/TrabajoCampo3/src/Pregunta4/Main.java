package Pregunta4;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Inventario inventario = new Inventario();
        int opcion;

        do {
            System.out.println("\n=== MENÚ INVENTARIO ===");
            System.out.println("1. Agregar producto (solo nombre)");
            System.out.println("2. Agregar producto (nombre y precio)");
            System.out.println("3. Agregar producto (nombre, precio y cantidad)");
            System.out.println("4. Mostrar inventario");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); 

            try {
                switch (opcion) {
                    case 1:
                        System.out.print("Ingrese el nombre: ");
                        String nombre1 = sc.nextLine();
                        inventario.agregarProducto(nombre1);
                        break;
                    case 2:
                        System.out.print("Ingrese el nombre: ");
                        String nombre2 = sc.nextLine();
                        System.out.print("Ingrese el precio: ");
                        double precio2 = sc.nextDouble();
                        sc.nextLine();
                        inventario.agregarProducto(nombre2, precio2);
                        break;
                    case 3:
                        System.out.print("Ingrese el nombre: ");
                        String nombre3 = sc.nextLine();
                        System.out.print("Ingrese el precio: ");
                        double precio3 = sc.nextDouble();
                        System.out.print("Ingrese la cantidad: ");
                        int cantidad3 = sc.nextInt();
                        sc.nextLine();
                        inventario.agregarProducto(nombre3, precio3, cantidad3);
                        break;
                    case 4:
                        inventario.mostrarProductos();
                        break;
                    case 5:
                        System.out.println("Saliendo del programa...");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (opcion != 5);

        sc.close();
    }
}

package Manejo_multiples_excepciones;
import java.util.Scanner;
class NumeroNegativoException extends Exception {
    public NumeroNegativoException(String mensaje) {
        super(mensaje);
    }
}
public class Main {
	
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        try {
	            System.out.print("Ingrese un número entero: ");
	            String entrada = sc.nextLine();

	            
	            int numero = Integer.parseInt(entrada);

	           
	            if (numero < 0) {
	                throw new NumeroNegativoException("El número no puede ser negativo.");
	            }

	            System.out.println("Número ingresado correctamente: " + numero);

	        } catch (NumberFormatException e) {
	            System.out.println("Error: Debe ingresar un valor numérico entero.");
	        } catch (NumeroNegativoException e) {
	            System.out.println("Error: " + e.getMessage());
	        } finally {
	            sc.close();
	        }
	    }

}
